package com.Hammadkhan950.myfoodapp.activity

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.Hammadkhan950.myfoodapp.R

class RegistrationActivity : AppCompatActivity() {
    lateinit var etProfile: EditText
    lateinit var etEmail: EditText
    lateinit var etAddress: EditText
    lateinit var etMobile: EditText
    lateinit var etPassword: EditText
    lateinit var etConfirmPassword: EditText
    lateinit var btnRegister: Button
    lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)
        title = "Register Yourself"
        etProfile = findViewById(R.id.etprofile)
        etEmail = findViewById(R.id.etemail)
        etAddress = findViewById(R.id.etaddress)
        etMobile = findViewById(R.id.etmobile)
        etPassword = findViewById(R.id.etPassword)
        etConfirmPassword = findViewById(R.id.etconfirmPassword)
        btnRegister = findViewById(R.id.btnRegister)
        sharedPreferences =
            getSharedPreferences("Registration", Context.MODE_PRIVATE)
        btnRegister.setOnClickListener {
            val profile = etProfile.text.toString()
            val email = etEmail.text.toString()
            val address = etAddress.text.toString()
            val mobileNumber = etMobile.text.toString()
            val password = etPassword.text.toString()
            val confirmPassword = etConfirmPassword.text.toString()
            savePreferences(mobileNumber, profile, email, address)
            Toast.makeText(this,"details saved",Toast.LENGTH_LONG).show()
            val intent=Intent(this, NewActivity::class.java)
//            val intent=Intent(this, ViewActivity::class.java)
//            intent.putExtra("profile",profile)
//            intent.putExtra("email",email)
//            intent.putExtra("address",address)
//            intent.putExtra("mobileNumber",mobileNumber)
//            intent.putExtra("password",password)
//            intent.putExtra("confirmPassword",confirmPassword)
           startActivity(intent)

        }

    }

    fun savePreferences(mobileNumber: String, name: String, email: String, address: String) {
        sharedPreferences.edit().putString("mobileNumber", mobileNumber).apply()
        sharedPreferences.edit().putString("name", name).apply()
        sharedPreferences.edit().putString("email", email).apply()
        sharedPreferences.edit().putString("address", address).apply()
    }

}